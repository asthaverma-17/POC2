import pandas as pd
from sqlalchemy import create_engine
from pathlib import Path


def run_ingestion(database_path: str = "sqlite:///aftersales.db", data_folder: str | Path | None = None):
    # Create SQLite DB
    engine = create_engine(database_path)

    # Load CSV files from data folder
    # The data directory is assumed to be at the workspace root alongside the aftersales-agent folder
    if data_folder is None:
        data_dir = Path(__file__).resolve().parent.parent / "data"
    else:
        data_dir = Path(data_folder)

    if not data_dir.is_dir():
        raise FileNotFoundError("Data directory not found: {data_dir}")

    for csv_file in data_dir.glob("*.csv"):
        df = pd.read_csv(csv_file)
        table_name = csv_file.stem
        df.to_sql(table_name, engine, if_exists="replace", index=False)

    print("Database created successfully.")


if __name__ == "__main__":
    run_ingestion()
