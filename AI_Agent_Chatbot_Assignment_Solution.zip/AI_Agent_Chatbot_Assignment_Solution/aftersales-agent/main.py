from langchain_core.prompts import PromptTemplate
from llm_init import llm

# bring in agent executor and KPI engine
from sql_agent import agent_executor
from kpi_engine import kpi_recommendation_engine

# allow database refresh
from ingestion import run_ingestion


analysis_prompt = PromptTemplate.from_template("""
You are an AI Aftersales Diagnostic Agent.

User Query:
{user_query}

SQL Result:
{sql_result}

Structure your response in 3 levels:

LEVEL 1 – DESCRIPTIVE:
State exact facts from the SQL result.

LEVEL 2 – DIAGNOSTIC:
Explain root cause by linking datasets logically.

LEVEL 3 – PROACTIVE:
Suggest 2-3 KPIs to monitor next.
Be specific and measurable.

Only use facts from SQL result.
Do NOT hallucinate.
""")

analysis_chain = analysis_prompt | llm

conversation_context = {}

def run_agent(user_query):
    
    # Step 1: Get raw SQL result
    sql_result = agent_executor.invoke({"input": user_query})["output"]
    
    # Step 2: Structured analysis
    structured_response = analysis_chain.invoke({
        "user_query": user_query,
        "sql_result": sql_result
    }).content
    
    # Step 3: KPI Engine
    suggested_kpis = kpi_recommendation_engine(structured_response)
    
    if suggested_kpis:
        structured_response += "\n\nAdditional Recommended KPIs:\n"
        for kpi in suggested_kpis:
            structured_response += f"- {kpi}\n"
    
    return structured_response


if __name__ == "__main__":
    # refresh the database tables from CSVs before running the agent
    run_ingestion()

    query = "Why did Customer X receive only 50% of their order for AX-4312?"
    response = run_agent(query)
    print(response)

    # query = "Our warehouse costs spiked last week. What happened?"
    # response = run_agent(query)
    # print(response)

