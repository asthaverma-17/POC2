import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

# load environment variables from a .env file in the project root
load_dotenv()

# ensure the OpenAI key is available under the expected name
# support either OPENAI_API_KEY or legacy OPEN_API_KEY
api_key =  os.getenv("OPEN_API_KEY")
if api_key:
    os.environ["OPENAI_API_KEY"] = api_key
else:
    raise RuntimeError("OpenAI API key not found in environment (OPENAI_API_KEY or OPEN_API_KEY)")

llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0
)