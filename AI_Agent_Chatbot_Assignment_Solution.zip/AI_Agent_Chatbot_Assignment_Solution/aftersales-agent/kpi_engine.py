def kpi_recommendation_engine(text):
    kpis = []

    if "fill rate" in text.lower():
        kpis.append("Reorder Point Accuracy")
        kpis.append("Safety Stock Coverage")
        kpis.append("Supplier Lead Time Variability")

    if "error rate" in text.lower():
        kpis.append("Rework Rate by Shift")
        kpis.append("Employee Overtime Ratio")

    if "sla" in text.lower():
        kpis.append("Equipment Utilization vs Labor Hours")
        kpis.append("Shift Productivity Index")

    return kpis


    