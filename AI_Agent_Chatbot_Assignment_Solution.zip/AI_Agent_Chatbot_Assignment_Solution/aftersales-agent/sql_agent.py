from langchain_community.utilities import SQLDatabase
from langchain_community.agent_toolkits.sql.base import create_sql_agent
from langchain_openai import ChatOpenAI
from llm_init import llm  

db = SQLDatabase.from_uri("sqlite:///aftersales.db")

# Create SQL Agent
agent_executor = create_sql_agent(
    llm=llm,
    db=db,
    agent_type="openai-tools",   # Required for modern OpenAI models
    verbose=True
)